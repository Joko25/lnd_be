<center>
    <br><br><br><br><br><br>
    <img src="assets/image/undraw_session.png" width="400"></img>
    <br>
    <b style="font-size: 20px !important;">Session Expired</b>
    <p>You cannot use this module or menu because you are session has been expired, please logout this application and re-login.</p>
</center>